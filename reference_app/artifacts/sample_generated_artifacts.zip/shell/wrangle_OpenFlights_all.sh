#!/bin/bash

# Bash shell script to wrangle/transform a raw mongoexport file
#
# Database Name: OpenFlights
# Generated on:  2021-11-05 21:27:10 UTC
# Template:      wrangle_all.txt

source ./env.sh

skip_download_flag=""  # set to "--skip-download" to bypass blob downloading


echo 'executing wrangle_OpenFlights_Airlines.sh ...'
./wrangle_OpenFlights_Airlines.sh $skip_download_flag

echo 'executing wrangle_OpenFlights_Airports.sh ...'
./wrangle_OpenFlights_Airports.sh $skip_download_flag

echo 'executing wrangle_OpenFlights_Countries.sh ...'
./wrangle_OpenFlights_Countries.sh $skip_download_flag

echo 'executing wrangle_OpenFlights_Planes.sh ...'
./wrangle_OpenFlights_Planes.sh $skip_download_flag

echo 'executing wrangle_OpenFlights_Routes.sh ...'
./wrangle_OpenFlights_Routes.sh $skip_download_flag


echo 'done'