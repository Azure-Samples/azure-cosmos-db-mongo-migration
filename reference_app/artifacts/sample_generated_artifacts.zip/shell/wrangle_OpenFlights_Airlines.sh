#!/bin/bash

# Bash shell script to download a raw mongoexport blob, transform it, 
# then import the transformed file to CosmosDB.
#
# Database Name: OpenFlights
# Generated on:  2021-11-05 21:27:10 UTC
# Template:      wrangle_one_blob.txt

source ./env.sh

mkdir -p tmp/OpenFlights/out
mkdir -p out/OpenFlights

python wrangle.py transform_blob \
    --db OpenFlights \
    --source-coll  Airlines \
    --in-container openflights-raw \
    --blobname OpenFlights__Airlines.json \
    --filename tmp/OpenFlights/OpenFlights__Airlines.json \
    --outfile  tmp/OpenFlights/OpenFlights__Airlines__wrangled.json \
    --out-container travel-airlines-adf $1 $2 $3 

echo ''
echo 'first line of input file: tmp/OpenFlights/OpenFlights__Airlines.json'
head -1 tmp/OpenFlights/OpenFlights__Airlines.json

echo ''
echo 'first line of output file: tmp/OpenFlights/OpenFlights__Airlines__wrangled.json'
head -1 tmp/OpenFlights/OpenFlights__Airlines__wrangled.json

if [[ $M2C_COSMOS_LOAD_METHOD == "mongoimport" ]];
then
    echo ''
    echo 'executing mongoimport to db: travel coll: Airlines ...' 

    mongoimport \
        --uri $M2C_COSMOS_MONGO_CONN_STRING \
        --db travel \
        --collection Airlines \
        --file tmp/OpenFlights/OpenFlights__Airlines__wrangled.json \
        --numInsertionWorkers $M2C_MONGOIMPORT_NWORKERS \
        --batchSize $M2C_MONGOIMPORT_BATCH_SIZE \
        --mode $M2C_MONGOIMPORT_MODE \
        --writeConcern "{w:0}" \
        --ssl

    echo 'mongoimport completed' 
fi 

if [[ $M2C_COSMOS_LOAD_METHOD == "dotnet_mongo_loader" ]];
then
    echo ''
    echo 'executing dotnet_mongo_loader to db: travel coll: Airlines ...' 

    dotnet run --project dotnet_mongo_loader/dotnet_mongo_loader.csproj \
        travel Airlines tmp/OpenFlights/OpenFlights__Airlines__wrangled.json \
        $M2C_DOTNETMONGOLOADER_TARGET $M2C_DOTNETMONGOLOADER_LOAD_IND \
        $M2C_DOTNETMONGOLOADER_DOCUMENT_ID_POLICY \
        --tracerInterval $M2C_DOTNETMONGOLOADER_TRACER_INTERVAL \
        --rowMaxRetries $M2C_DOTNETMONGOLOADER_ROW_MAX_RETRIES \
        $M2C_DOTNETMONGOLOADER_VERBOSE
fi

if [[ $M2C_WRANGLING_CLEANUP == "cleanup" ]];
then
    echo ''
    echo 'deleting the downloaded and wrangled files to save disk space...'
    rm tmp/OpenFlights/OpenFlights__Airlines.json
    rm tmp/OpenFlights/OpenFlights__Airlines__wrangled.json
fi

echo 'done'