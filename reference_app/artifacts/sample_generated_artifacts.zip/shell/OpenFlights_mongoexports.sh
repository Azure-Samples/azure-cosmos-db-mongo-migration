#!/bin/bash

# Bash shell script to export each source collection via mongoexport.
#
# Database Name: OpenFlights
# Generated on:  2021-11-05 21:27:10 UTC
# Template:      mongoexport_script.txt

source env.sh

mkdir -p data/source/mongoexports


echo ''
echo 'mongoexport:  database: OpenFlights container: Airlines'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Airlines.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/OpenFlights \
    --collection Airlines \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Airlines.json


echo ''
echo 'mongoexport:  database: OpenFlights container: Airports'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Airports.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/OpenFlights \
    --collection Airports \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Airports.json


echo ''
echo 'mongoexport:  database: OpenFlights container: Countries'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Countries.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/OpenFlights \
    --collection Countries \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Countries.json


echo ''
echo 'mongoexport:  database: OpenFlights container: Planes'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Planes.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/OpenFlights \
    --collection Planes \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Planes.json


echo ''
echo 'mongoexport:  database: OpenFlights container: Routes'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Routes.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/OpenFlights \
    --collection Routes \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/OpenFlights/OpenFlights__Routes.json


echo 'done'