#!/bin/bash

# Bash shell script to export each source collection via mongoexport.
#
# Database Name: olympics
# Generated on:  2021-11-05 21:27:09 UTC
# Template:      mongoexport_script.txt

source env.sh

mkdir -p data/source/mongoexports


echo ''
echo 'mongoexport:  database: olympics container: countries'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__countries.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection countries \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__countries.json


echo ''
echo 'mongoexport:  database: olympics container: g1896_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1896_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1896_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1896_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1900_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1900_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1900_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1900_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1904_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1904_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1904_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1904_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1906_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1906_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1906_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1906_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1908_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1908_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1908_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1908_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1912_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1912_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1912_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1912_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1920_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1920_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1920_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1920_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1924_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1924_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1924_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1924_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1924_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1924_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1924_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1924_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1928_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1928_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1928_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1928_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1928_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1928_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1928_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1928_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1932_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1932_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1932_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1932_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1932_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1932_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1932_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1932_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1936_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1936_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1936_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1936_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1936_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1936_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1936_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1936_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1948_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1948_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1948_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1948_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1948_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1948_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1948_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1948_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1952_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1952_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1952_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1952_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1952_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1952_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1952_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1952_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1956_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1956_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1956_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1956_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1956_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1956_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1956_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1956_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1960_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1960_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1960_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1960_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1960_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1960_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1960_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1960_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1964_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1964_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1964_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1964_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1964_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1964_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1964_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1964_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1968_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1968_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1968_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1968_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1968_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1968_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1968_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1968_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1972_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1972_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1972_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1972_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1972_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1972_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1972_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1972_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1976_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1976_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1976_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1976_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1976_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1976_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1976_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1976_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1980_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1980_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1980_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1980_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1980_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1980_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1980_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1980_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1984_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1984_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1984_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1984_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1984_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1984_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1984_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1984_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1988_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1988_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1988_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1988_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1988_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1988_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1988_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1988_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1992_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1992_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1992_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1992_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1992_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1992_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1992_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1992_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1994_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1994_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1994_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1994_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g1996_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1996_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1996_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1996_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g1998_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1998_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g1998_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g1998_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g2000_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2000_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g2000_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2000_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g2002_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2002_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g2002_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2002_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g2004_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2004_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g2004_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2004_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g2006_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2006_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g2006_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2006_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g2008_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2008_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g2008_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2008_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g2010_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2010_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g2010_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2010_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g2012_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2012_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g2012_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2012_summer.json


echo ''
echo 'mongoexport:  database: olympics container: g2014_winter'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2014_winter.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g2014_winter \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2014_winter.json


echo ''
echo 'mongoexport:  database: olympics container: g2016_summer'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2016_summer.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection g2016_summer \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__g2016_summer.json


echo ''
echo 'mongoexport:  database: olympics container: games'
echo '    to file:  /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__games.json'

mongoexport \
    --uri $M2C_SOURCE_MONGODB_ATLAS_CONN_STR/olympics \
    --collection games \
    --out /Users/cjoakim/github/azure-cosmos-db-mongo-migration/reference_app/data/mongoexports/olympics/olympics__games.json


echo 'done'